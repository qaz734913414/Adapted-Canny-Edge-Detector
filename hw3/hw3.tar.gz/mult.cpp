/*
 * mult.cpp
 *
 *  Created on: Oct 23, 2018
 *      Author: xuyihan
 */
#include "mult.h"
void Mult::action() {
	f = a * b;
}

